// Check if user is logged in
const currentUser = JSON.parse(localStorage.getItem('currentUser'));
if (!currentUser) {
    window.location.href = 'index.html';
}

// Get booking ID from URL
const urlParams = new URLSearchParams(window.location.search);
const bookingId = parseInt(urlParams.get('booking'));
const bookings = JSON.parse(localStorage.getItem('bookings')) || [];
const booking = bookings.find(b => b.id === bookingId);

if (!booking) {
    alert('Invalid booking ID!');
    window.location.href = 'home.html';
}

const orderItems = JSON.parse(localStorage.getItem('orderItems')) || [];
const bookingItems = orderItems.filter(item => item.bookingId === bookingId);

// Calculate bill
function calculateBill() {
    const subtotal = bookingItems.reduce((total, item) => total + item.price * item.quantity, 0);
    const discountCode = document.getElementById('discount-code').value.trim();
    const discount = discountCode === 'SAVE10' ? subtotal * 0.1 : 0;
    const discountedAmount = subtotal - discount;
    const serviceTax = discountedAmount * 0.03;
    const cgst = discountedAmount * 0.025;
    const sgst = discountedAmount * 0.025;
    const tip = parseFloat(document.getElementById('tip-amount').value) || 0;
    const donation = parseFloat(document.getElementById('donation-amount').value) || 0;

    const total = discountedAmount + serviceTax + cgst + sgst + tip + donation;

    return { subtotal, discount, serviceTax, cgst, sgst, tip, donation, total };
}

// Display bill
function displayBill() {
    const billDetails = document.getElementById('bill-details');
    const bill = calculateBill();

    billDetails.innerHTML = `
        <div class="bill-pdf">
            <div class="bill-header">
                <h2>RESTOBILLS</h2>
                <p>Invoice #${bookingId}</p>
            </div>
            <div class="bill-meta">
                <div>
                    <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
                    <p><strong>Customer:</strong> ${currentUser.name}</p>
                </div>
                <div>
                    <p><strong>Table:</strong> ${booking.tableIds.join(', ')}</p>
                    <p><strong>Seating:</strong> ${booking.ac.toUpperCase()}</p>
                </div>
            </div>
            <div class="bill-items">
                ${bookingItems.map(item => `
                    <div class="bill-item">
                        <span>${item.name} x ${item.quantity}</span>
                        <span>₹${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `).join('')}
            </div>
            <div class="tax-details">
                ${Object.entries(bill).map(([key, value]) => `
                    <div class="bill-item">
                        <span>${key.replace(/([A-Z])/g, ' $1')}</span>
                        <span>₹${value.toFixed(2)}</span>
                    </div>
                `).join('')}
            </div>
            <div class="grand-total">
                <span>Grand Total: ₹${bill.total.toFixed(2)}</span>
            </div>
        </div>
    `;
}

// Handle payment method selection
function selectPayment(method) {
    document.querySelectorAll('.btn-payment').forEach(btn => btn.classList.remove('selected'));
    document.querySelector(`[onclick="selectPayment('${method}')"]`).classList.add('selected');
    
    document.getElementById('online-payment-details').classList.toggle('hidden', method !== 'online');
    document.getElementById('payment-verification').classList.remove('hidden');
}

// Handle payment verification
document.getElementById('verify-payment-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const restaurantCode = document.getElementById('restaurant-code').value.trim();
    const receiverName = document.getElementById('receiver-name').value.trim();
    const amountReceived = parseFloat(document.getElementById('amount-received').value);
    const bill = calculateBill();

    if (restaurantCode !== '1234abcd') {
        alert('Invalid restaurant code!');
        return;
    }
    if (amountReceived < bill.total) {
        alert('Amount received is less than the bill amount!');
        return;
    }

    // Mark booking as completed
    const bookingIndex = bookings.findIndex(b => b.id === bookingId);
    bookings[bookingIndex].completed = true;
    localStorage.setItem('bookings', JSON.stringify(bookings));

    // Save bill to history
    const bills = JSON.parse(localStorage.getItem('bills')) || [];
    bills.push({
        id: Date.now(),
        bookingId,
        userId: currentUser.id,
        amount: bill.total,
        items: bookingItems,
        timestamp: new Date().toISOString()
    });
    localStorage.setItem('bills', JSON.stringify(bills));

    // Show review modal
    document.getElementById('review-modal').style.display = 'block';
});

// Handle review submission
document.getElementById('review-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const rating = parseInt(document.getElementById('rating').value);
    const comment = document.getElementById('review-text').value.trim();

    // Save review
    const reviews = JSON.parse(localStorage.getItem('reviews')) || [];
    reviews.push({
        id: Date.now(),
        restaurantId: booking.restaurantId,
        userId: currentUser.id,
        userName: currentUser.name,
        rating,
        comment,
        timestamp: new Date().toISOString()
    });
    localStorage.setItem('reviews', JSON.stringify(reviews));

    alert('Thank you for your review! Redirecting to homepage...');
    window.location.href = 'home.html';
});

// Close modal
document.querySelector('.close').onclick = function() {
    document.getElementById('review-modal').style.display = 'none';
};

// Initialize
displayBill();
