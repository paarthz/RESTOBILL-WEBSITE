// Check if user is logged in
const currentUser = JSON.parse(localStorage.getItem('currentUser'));
if (!currentUser) {
    window.location.href = 'index.html';
}

// Get booking details from URL
const urlParams = new URLSearchParams(window.location.search);
const bookingId = urlParams.get('booking');
const booking = JSON.parse(localStorage.getItem('bookings')).find(b => b.id === parseInt(bookingId));

if (!booking) {
    window.location.href = 'home.html';
}

// Get restaurant data
const restaurants = {
    pizza: {
        name: 'Pizza Paradise',
        menu: {
            pizzas: [
                { name: 'Margherita', price: 299, image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002' },
                { name: 'Pepperoni', price: 399, image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e' }
            ],
            toppings: [
                { name: 'Extra Cheese', price: 50 },
                { name: 'Mushrooms', price: 40 },
                { name: 'Olives', price: 30 }
            ]
        }
    },
    indian: {
        name: 'Spice Garden',
        menu: {
            starters: [
                { name: 'Paneer Tikka', price: 249, image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0' }
            ],
            mains: [
                { name: 'Butter Chicken', price: 349, image: 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db' }
            ],
            breads: [
                { name: 'Butter Naan', price: 49, image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950' }
            ],
            drinks: [
                { name: 'Mango Lassi', price: 99, image: 'https://images.unsplash.com/photo-1571006682985-88f945e95754' }
            ]
        }
    },
    icecream: {
        name: 'Scoop Haven',
        menu: {
            icecreams: [
                { name: 'Vanilla Bean', price: 99, image: 'https://images.unsplash.com/photo-1570197571499-166b36435e9f' }
            ]
        }
    }
};

const restaurant = restaurants[booking.restaurantId];
const cart = new Map();

// Display restaurant info
function displayRestaurantInfo() {
    const restaurantInfo = document.getElementById('restaurant-info');
    restaurantInfo.innerHTML = `
        <h2>${restaurant.name}</h2>
        <p>Booking ID: ${bookingId}</p>
        <p>Table(s): ${booking.tableIds.join(', ')}</p>
        <p>Date & Time: ${new Date(booking.datetime).toLocaleString()}</p>
    `;
}

// Display menu
function displayMenu() {
    const menuSections = document.getElementById('menu-sections');
    menuSections.innerHTML = '';
    
    Object.entries(restaurant.menu).forEach(([category, items]) => {
        const section = document.createElement('div');
        section.className = 'menu-section';
        section.innerHTML = `
            <h3>${category.charAt(0).toUpperCase() + category.slice(1)}</h3>
            ${items.map(item => `
                <div class="menu-item">
                    <img src="${item.image}" alt="${item.name}">
                    <div class="menu-item-details">
                        <h4>${item.name}</h4>
                        <p class="menu-item-price">₹${item.price}</p>
                    </div>
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="updateQuantity('${item.name}', ${item.price}, -1)">-</button>
                        <span id="quantity-${item.name.replace(/\s+/g, '-')}">${cart.get(item.name)?.quantity || 0}</span>
                        <button class="quantity-btn" onclick="updateQuantity('${item.name}', ${item.price}, 1)">+</button>
                    </div>
                </div>
            `).join('')}
        `;
        menuSections.appendChild(section);
    });
}

// Update item quantity
function updateQuantity(itemName, price, change) {
    const currentItem = cart.get(itemName) || { quantity: 0, price };
    const newQuantity = currentItem.quantity + change;
    
    if (newQuantity >= 0) {
        if (newQuantity === 0) {
            cart.delete(itemName);
        } else {
            cart.set(itemName, { quantity: newQuantity, price });
        }
        updateDisplay();
    }
}

// Update display
function updateDisplay() {
    // Update quantity displays
    cart.forEach((item, name) => {
        const quantityElement = document.getElementById(`quantity-${name.replace(/\s+/g, '-')}`);
        if (quantityElement) {
            quantityElement.textContent = item.quantity;
        }
    });
    
    // Update cart
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    
    if (cart.size === 0) {
        cartItems.innerHTML = '<p>Your cart is empty</p>';
        cartTotal.innerHTML = '';
        return;
    }
    
    let total = 0;
    cartItems.innerHTML = '';
    
    cart.forEach((item, name) => {
        const itemTotal = item.quantity * item.price;
        total += itemTotal;
        
        cartItems.innerHTML += `
            <div class="cart-item">
                <span>${name} x ${item.quantity}</span>
                <span>₹${itemTotal}</span>
            </div>
        `;
    });
    
    cartTotal.innerHTML = `Total: ₹${total}`;
}

// Proceed to bill
function proceedToBill() {
    if (cart.size === 0) {
        alert('Please select at least one item');
        return;
    }
    
    // Save order items
    const orderItems = [];
    cart.forEach((item, name) => {
        orderItems.push({
            bookingId: parseInt(bookingId),
            name,
            quantity: item.quantity,
            price: item.price
        });
    });
    
    const existingOrders = JSON.parse(localStorage.getItem('orderItems')) || [];
    localStorage.setItem('orderItems', JSON.stringify([...existingOrders, ...orderItems]));
    
    // Redirect to bill page
    window.location.href = `bill.html?booking=${bookingId}`;
}

// Logout
document.getElementById('logout').onclick = function() {
    localStorage.removeItem('currentUser');
    window.location.href = 'index.html';
};

// Initialize
displayRestaurantInfo();
displayMenu();
updateDisplay();