// Check if user is logged in
const currentUser = JSON.parse(localStorage.getItem('currentUser'));
if (!currentUser) {
    window.location.href = 'index.html';
}

// Restaurant data
const restaurants = {
    pizza: {
        name: 'Pizza Paradise',
        menu: {
            pizzas: [
                { name: 'Margherita', price: 299, image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002' },
                { name: 'Pepperoni', price: 399, image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e' },
                // Add more pizzas...
            ],
            toppings: [
                { name: 'Extra Cheese', price: 50 },
                { name: 'Mushrooms', price: 40 },
                { name: 'Olives', price: 30 }
            ]
        },
        tables: [
            { id: 1, capacity: 2 },
            { id: 2, capacity: 4 },
            { id: 3, capacity: 6 },
            // Add more tables...
        ]
    },
    indian: {
        name: 'Spice Garden',
        menu: {
            starters: [
                { name: 'Paneer Tikka', price: 249, image: 'https://example.com/paneer-tikka.jpg' },
                // Add more starters...
            ],
            mains: [
                { name: 'Butter Chicken', price: 349, image: 'https://example.com/butter-chicken.jpg' },
                // Add more main courses...
            ],
            breads: [
                { name: 'Butter Naan', price: 49, image: 'https://example.com/naan.jpg' },
                // Add more breads...
            ],
            drinks: [
                { name: 'Mango Lassi', price: 99, image: 'https://example.com/lassi.jpg' },
                // Add more drinks...
            ]
        },
        tables: [
            { id: 1, capacity: 2 },
            { id: 2, capacity: 4 },
            // Add more tables...
        ]
    },
    icecream: {
        name: 'Scoop Haven',
        menu: {
            icecreams: [
                { name: 'Vanilla Bean', price: 99, image: 'https://example.com/vanilla.jpg' },
                // Add more ice creams...
            ]
        },
        tables: [
            { id: 1, capacity: 2 },
            { id: 2, capacity: 4 },
            // Add more tables...
        ]
    }
};

// Booking data
let bookings = JSON.parse(localStorage.getItem('bookings')) || [];

// Reviews data
let reviews = JSON.parse(localStorage.getItem('reviews')) || [];

// Show booking form
function showBookingForm(restaurantId) {
    const modal = document.getElementById('booking-modal');
    const form = document.getElementById('booking-form');
    
    // Pre-fill user details
    document.getElementById('booking-name').value = currentUser.name;
    document.getElementById('booking-email').value = currentUser.email;
    document.getElementById('booking-phone').value = currentUser.phone;
    
    // Load available tables
    loadTables(restaurantId);
    
    modal.style.display = 'block';
    
    // Store selected restaurant for form submission
    form.dataset.restaurant = restaurantId;
}

// Load tables for booking
function loadTables(restaurantId) {
    const tablesContainer = document.getElementById('tables-container');
    const restaurant = restaurants[restaurantId];
    
    tablesContainer.innerHTML = '';
    
    restaurant.tables.forEach(table => {
        const isBooked = bookings.some(booking => 
            booking.restaurantId === restaurantId && 
            booking.tableId === table.id &&
            !booking.completed
        );
        
        const tableElement = document.createElement('div');
        tableElement.className = `table ${isBooked ? 'booked' : 'available'}`;
        tableElement.innerHTML = `
            Table ${table.id}<br>
            Capacity: ${table.capacity}
        `;
        
        if (!isBooked) {
            tableElement.onclick = () => selectTable(tableElement, table.id);
        }
        
        tablesContainer.appendChild(tableElement);
    });
}

// Handle table selection
function selectTable(element, tableId) {
    const selected = element.classList.contains('selected');
    element.classList.toggle('selected');
    
    // Store selected table IDs in form data
    const form = document.getElementById('booking-form');
    const selectedTables = form.dataset.selectedTables ? 
        JSON.parse(form.dataset.selectedTables) : [];
    
    if (selected) {
        const index = selectedTables.indexOf(tableId);
        if (index > -1) selectedTables.splice(index, 1);
    } else {
        selectedTables.push(tableId);
    }
    
    form.dataset.selectedTables = JSON.stringify(selectedTables);
}

// Show menu
function showMenu(restaurantId) {
    const modal = document.getElementById('menu-modal');
    const menuContainer = document.getElementById('menu-container');
    const restaurant = restaurants[restaurantId];
    
    let menuHTML = '';
    
    // Generate menu sections
    Object.entries(restaurant.menu).forEach(([category, items]) => {
        menuHTML += `
            <div class="menu-section">
                <h3>${category.charAt(0).toUpperCase() + category.slice(1)}</h3>
                <div class="menu-items">
                    ${items.map(item => `
                        <div class="menu-item">
                            <img src="${item.image}" alt="${item.name}">
                            <div class="menu-item-details">
                                <h4>${item.name}</h4>
                                <p class="menu-item-price">₹${item.price}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    });
    
    menuContainer.innerHTML = menuHTML;
    modal.style.display = 'block';
}

// Close modals
document.querySelectorAll('.close').forEach(closeBtn => {
    closeBtn.onclick = function() {
        this.closest('.modal').style.display = 'none';
    }
});

// Handle booking form submission
document.getElementById('booking-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const restaurantId = this.dataset.restaurant;
    const selectedTables = JSON.parse(this.dataset.selectedTables || '[]');
    
    if (selectedTables.length === 0) {
        alert('Please select at least one table');
        return;
    }
    
    const booking = {
        id: Date.now(),
        restaurantId,
        userId: currentUser.id,
        tableIds: selectedTables,
        datetime: document.getElementById('booking-datetime').value,
        people: document.getElementById('booking-people').value,
        ac: document.getElementById('booking-ac').value,
        notes: document.getElementById('booking-notes').value,
        completed: false
    };
    
    bookings.push(booking);
    localStorage.setItem('bookings', JSON.stringify(bookings));
    
    alert('Table booked successfully!');
    document.getElementById('booking-modal').style.display = 'none';
    
    // Redirect to menu selection
    window.location.href = `menu.html?booking=${booking.id}`;
});

// Load reviews
function loadReviews() {
    Object.keys(restaurants).forEach(restaurantId => {
        const reviewsContainer = document.getElementById(`${restaurantId}-reviews`);
        const restaurantReviews = reviews.filter(review => review.restaurantId === restaurantId);
        
        reviewsContainer.innerHTML = restaurantReviews.map(review => `
            <div class="review">
                <div class="rating">${'★'.repeat(review.rating)}${'☆'.repeat(10-review.rating)}</div>
                <p>${review.comment}</p>
                <small>- ${review.userName}</small>
            </div>
        `).join('') || '<p>No reviews yet</p>';
    });
}

// Logout
document.getElementById('logout').onclick = function() {
    localStorage.removeItem('currentUser');
    window.location.href = 'index.html';
};

// Initialize
loadReviews();